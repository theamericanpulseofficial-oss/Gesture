# Gesture Control (Android) — port of "Control_pc_using_Hand-Gesture"

Phone ka apna camera use karke, hand gestures se **poore phone ko background me,
dusre apps ke upar bhi** control karta hai — bilkul us PC project jaisa hi kaam,
bas desktop ki jagah Android par.

## What changed in this version

- **Runs in the background** (`GestureTrackingService`, a foreground service) —
  camera aur gesture control tab bhi chalte hain jab aap koi aur app khol lo.
- **Real on-screen cursor**: ek green ring cursor hamesha aapki **palm ke center**
  (wrist + 4 knuckles ka average, fingertip nahi) se move hota hai — bilkul PC
  wale mouse pointer jaisa. Ye cursor ek system-wide overlay window me draw hota
  hai, isliye kisi bhi app ke upar dikhta hai.
- **Mirroring bug fixed**: pehle hand skeleton ulti direction me move ho raha tha
  kyunki image do baar mirror ho rahi thi (ek baar camera capture me, ek baar
  screen par draw karte waqt). Ab sirf ek hi jagah (capture time par) mirror
  hota hai, so skeleton/cursor aapke real hand movement ko sahi direction me
  follow karta hai.
- **Naye gestures**:

| Gesture                                   | Action                                   |
|--------------------------------------------|-------------------------------------------|
| Hath khula rakho (koi pinch/fist nahi)     | Cursor palm-center se track karta hai (idle, green) |
| Thumb + Index pinch                        | **Tap/Click** cursor ki position par (orange) |
| Thumb + Middle pinch                       | **Long-press** cursor ki position par (magenta) |
| **Fist bana ke hath move karo**            | **Drag & Drop** — fist band karte hi "press" hota hai, hath move karne se drag hota hai, fist khol do to "drop"/release ho jata hai (red) |
| Index + Middle up (peace sign) + move      | **Scroll** — jis direction (up/down/left/right) me hath move karoge, usi direction me scroll hoga (cyan) |

## Required permissions (2 one-time setup steps in the app)

1. **"Display over other apps"** — isके bina cursor overlay dusre apps ke upar
   nahi dikh sakta. App khol ke pehla button dabao, Android Settings me toggle ON
   karo.
2. **Accessibility Service** — Android me koi bhi app direct tap/scroll/drag
   inject nahi kar sakta (jaise PC par pyautogui karta tha); iske liye Android ka
   official, non-root tarika **Accessibility API** hai. Dusra button dabao,
   Settings me "Gesture Control" ko ON karo.

Dono ho jaane ke baad "3. Start" dabao — Camera permission maangega, de do, aur
service background me chalna shuru ho jayegi. Ab app minimize kar sakte ho, cursor
kahin bhi (home screen, koi bhi app) dikhega aur gestures kaam karenge.

Rokne ke liye: ya to app kholke "Stop" dabao, ya notification tray me "Gesture
Control running" notification ke "Stop" button se.

## Project structure

```
app/src/main/java/com/gesturecontrol/app/
  Config.kt                      -> thresholds (was config.py)
  GestureClassifier.kt           -> gesture logic + palm-center (was gesture_recognition.py)
  HandLandmarkerHelper.kt        -> MediaPipe wrapper, single-mirror fix (was hand_tracking.py)
  GestureAccessibilityService.kt -> tap/long-press/drag/scroll dispatch (was mouse_control.py)
  CursorOverlayView.kt           -> system-wide cursor + skeleton overlay
  GestureTrackingService.kt      -> background foreground service (was the main loop)
  MainActivity.kt                -> permission setup + start/stop control panel
app/src/main/assets/hand_landmarker.task  -> same model file as the PC repo
```

## How to build

**Option A — Android Studio (PC):** open `GestureControl/` in Android Studio,
let Gradle sync, run on a device with Android 8.0 (API 26) or newer.

**Option B — from your phone only (GitHub Actions):** a
`.github/workflows/build.yml` is included so GitHub's servers compile the APK.
Push this project to a GitHub repo (via Termux + git, or upload the zip + a
workflow that extracts it) and download the built APK from the Actions tab's
Artifacts. See earlier chat instructions for the exact Termux/GitHub steps.

## Known limitations

- Drag & drop uses Android's `continueStroke` API, which needs **Android 8.0
  (API 26)+** — that's why `minSdk` is 26 now instead of 24.
- Overlay assumes the phone stays in the orientation it started tracking in
  (portrait); rotating mid-session isn't handled specially yet.
- Gesture thresholds (`Config.kt`) are best-effort normalized guesses — tweak
  `PINCH_THRESHOLD` / `SCROLL_MOVE_THRESHOLD` if clicks or scrolls feel too
  sensitive or not sensitive enough for your hand/camera distance.
- Not yet build-tested on a physical device from this session (no internet/
  Gradle in the sandbox that generated it) — please build once and report any
  compile errors so they can be fixed quickly.
