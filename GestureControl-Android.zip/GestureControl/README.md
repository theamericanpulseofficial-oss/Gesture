# Gesture Control (Android) — port of "Control_pc_using_Hand-Gesture"

Isi PC project ka Android version: phone ka apna camera use karke, hand gestures se
**phone khud** control hota hai (tap / long-press / scroll) — koi PC/laptop involved nahi.

Same model file (`hand_landmarker.task`) use hota hai, aur gesture logic wahi hai jo
`gesture_recognition.py` me tha, bas Android ke liye adapt kiya gaya hai.

## Gesture mapping (PC -> Android)

| PC gesture (webcam)                | PC action (pyautogui)     | Android action (Accessibility API) |
|-------------------------------------|----------------------------|--------------------------------------|
| Index finger only up                 | Move cursor                | Track/point only (visual, green)     |
| Thumb + Index pinch                  | Left Click                 | **Tap** at fingertip position        |
| Thumb + Middle pinch                 | Right Click                | **Long-press** at fingertip position |
| Index + Middle up (peace sign) + move up/down | Scroll up/down     | **Scroll swipe** up/down             |
| Closed fist                          | Pause (safety)              | Pause (no actions dispatched)        |
| 'Q' key                              | Quit                        | "Stop" button in the app             |

## Why Accessibility Service?

Android apps can't inject taps/swipes system-wide the way `pyautogui` does on a PC.
The official, non-root way to do this is Android's **Accessibility API**
(`dispatchGesture`) — same mechanism used by real accessibility/automation apps.
The app will ask you to enable it once from Settings.

## Project structure

```
app/src/main/java/com/gesturecontrol/app/
  Config.kt                     -> thresholds (was config.py)
  GestureClassifier.kt          -> gesture logic (was gesture_recognition.py)
  HandLandmarkerHelper.kt       -> MediaPipe wrapper (was hand_tracking.py)
  GestureAccessibilityService.kt-> performs tap/long-press/scroll (was mouse_control.py)
  OverlayView.kt                -> draws hand skeleton + HUD border
  MainActivity.kt               -> camera loop + wiring (was the main loop)
app/src/main/assets/hand_landmarker.task  -> same model file as the PC repo
```

## How to build — Option A: on a PC with Android Studio

1. Open this `GestureControl/` folder as a project in **Android Studio** (Hedgehog or
   newer). It will auto-download the Gradle wrapper and dependencies the first time
   (needs internet).
2. Let Gradle sync. It will pull:
   - `com.google.mediapipe:tasks-vision:0.10.14`
   - CameraX libraries
3. Connect an Android phone (Android 7.0 / API 24+) with USB debugging on, or use an
   emulator with a virtual camera.
4. Click **Run**.

## How to build — Option B: entirely from your phone (no PC, no Android Studio)

A `.github/workflows/build.yml` is included, so **GitHub's servers compile the APK
for you** — your phone just needs Termux (to push the code) and a browser (to
download the finished APK).

1. **Install Termux** on your phone (get it from F-Droid, not the outdated Play Store
   build): https://f-droid.org/packages/com.termux/
2. **Create a free GitHub account** (github.com) if you don't have one, and create a
   new **empty** repository (no README/license), e.g. `GestureControl`.
3. **Create a Personal Access Token**: GitHub app/site → Settings → Developer
   settings → Personal access tokens → Generate new token (classic) → tick `repo`
   scope → copy it (you'll use it as your git password).
4. Download the zip I gave you onto your phone (it'll land in `Downloads`), then in
   Termux:
   ```bash
   pkg install git -y
   termux-setup-storage
   cd storage/downloads
   unzip GestureControl-Android.zip
   cd GestureControl
   git init
   git branch -M main
   git add .
   git commit -m "initial commit"
   git remote add origin https://github.com/<your-username>/GestureControl.git
   git push -u origin main
   ```
   When it asks for a password, paste the **token** from step 3 (not your GitHub
   password).
5. On GitHub (app or browser), open your repo → **Actions** tab → you'll see
   "Build APK" running automatically → wait for the green checkmark (a few minutes).
6. Open that finished run → under **Artifacts**, download
   `GestureControl-debug-apk` (it's a zip containing `app-debug.apk`).
7. On your phone, extract that zip, tap `app-debug.apk` to install (you'll need to
   allow "Install unknown apps" for your browser/files app the first time Android
   asks).

That's it — no PC needed anywhere in this flow.

## How to use the app

1. Launch the app, tap **"Enable Access"** → in Android Settings, find
   **Gesture Control** under Accessibility → turn it ON → go back to the app.
2. Grant the **Camera** permission when asked.
3. Tap **"Start"**. Hold the phone so the front camera sees your hand.
4. Use the gestures from the table above. The colored border shows the current
   state (green = tracking, orange = tap, magenta = long-press, cyan = scroll,
   red = paused).
5. Tap **"Stop"** to end (equivalent of pressing 'Q' on the PC version).

## Known limitations (things to improve later)

- Camera only runs while the app is in the foreground (the PC version's webcam loop
  runs the whole time it's open; here, backgrounding the app pauses the camera).
  A foreground `Service` could be added later to keep it running with the screen off.
- Gesture thresholds (`Config.kt`) are normalized guesses ported from the PC pixel
  thresholds — you may need to tweak `PINCH_THRESHOLD` for your hand/camera distance.
- Only tested logic-wise, not yet built/run on a physical device from this session
  (no internet/Gradle access in the sandbox that generated it) — please build once in
  Android Studio and report any compile errors so they can be fixed.
