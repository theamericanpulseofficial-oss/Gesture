package com.gesturecontrol.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark

/**
 * Android equivalent of hand_tracking.py's draw_landmarks() + the dashboard border
 * from the PC "visual dashboard" feature.
 */
class OverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var landmarks: List<NormalizedLandmark> = emptyList()
    private var mirror = true
    private var borderColor = Color.RED

    private val pointPaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.FILL
        isAntiAlias = true
    }
    private val linePaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.STROKE
        strokeWidth = 6f
        isAntiAlias = true
    }
    private val borderPaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 18f
        isAntiAlias = true
    }

    private val connections = listOf(
        0 to 1, 1 to 2, 2 to 3, 3 to 4,
        0 to 5, 5 to 6, 6 to 7, 7 to 8,
        5 to 9, 9 to 10, 10 to 11, 11 to 12,
        9 to 13, 13 to 14, 14 to 15, 15 to 16,
        13 to 17, 17 to 18, 18 to 19, 19 to 20,
        0 to 17, 5 to 9, 9 to 13, 13 to 17
    )

    fun update(newLandmarks: List<NormalizedLandmark>, mirrorHorizontally: Boolean, stateColor: Int) {
        landmarks = newLandmarks
        mirror = mirrorHorizontally
        borderColor = stateColor
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        borderPaint.color = borderColor
        canvas.drawRect(4f, 4f, width - 4f, height - 4f, borderPaint)

        if (landmarks.isEmpty()) return

        fun px(nx: Float) = if (mirror) (1f - nx) * width else nx * width
        fun py(ny: Float) = ny * height

        for ((a, b) in connections) {
            if (a < landmarks.size && b < landmarks.size) {
                canvas.drawLine(
                    px(landmarks[a].x()), py(landmarks[a].y()),
                    px(landmarks[b].x()), py(landmarks[b].y()),
                    linePaint
                )
            }
        }
        for (lm in landmarks) {
            canvas.drawCircle(px(lm.x()), py(lm.y()), 8f, pointPaint)
        }
    }
}
