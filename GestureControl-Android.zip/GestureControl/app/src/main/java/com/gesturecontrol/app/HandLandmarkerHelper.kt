package com.gesturecontrol.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Log
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult

/**
 * Direct Android equivalent of hand_tracking.py's HandTracker class, using the SAME
 * hand_landmarker.task model file bundled with the PC project (see app/src/main/assets/).
 */
class HandLandmarkerHelper(
    private val context: Context,
    private val onResult: (HandLandmarkerResult, Int, Int) -> Unit,
    private val onError: (String) -> Unit
) {
    private var handLandmarker: HandLandmarker? = null

    init {
        setup()
    }

    private fun setup() {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath("hand_landmarker.task")
                .setDelegate(Delegate.CPU)
                .build()

            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(Config.MAX_NUM_HANDS)
                .setMinHandDetectionConfidence(Config.MIN_DETECTION_CONFIDENCE)
                .setMinHandPresenceConfidence(Config.MIN_PRESENCE_CONFIDENCE)
                .setMinTrackingConfidence(Config.MIN_TRACKING_CONFIDENCE)
                .setResultListener { result, input -> onResult(result, input.width, input.height) }
                .setErrorListener { e -> onError(e.message ?: "HandLandmarker error") }
                .build()

            handLandmarker = HandLandmarker.createFromOptions(context, options)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to init HandLandmarker", e)
            onError("Failed to load model: ${e.message}")
        }
    }

    /** Feed one camera frame in. Safe to call repeatedly from the analyzer thread. */
    fun detectAsync(imageProxy: ImageProxy, rotationDegrees: Int, isFrontCamera: Boolean) {
        val landmarker = handLandmarker
        if (landmarker == null) {
            imageProxy.close()
            return
        }
        try {
            val bitmap = imageProxy.toBitmap()
            val processed = rotateAndMirror(bitmap, rotationDegrees, isFrontCamera)
            val mpImage: MPImage = BitmapImageBuilder(processed).build()
            landmarker.detectAsync(mpImage, System.currentTimeMillis())
        } catch (e: Exception) {
            Log.e(TAG, "detectAsync failed", e)
        } finally {
            imageProxy.close()
        }
    }

    fun close() {
        handLandmarker?.close()
        handLandmarker = null
    }

    private fun rotateAndMirror(bitmap: Bitmap, rotationDegrees: Int, mirror: Boolean): Bitmap {
        val matrix = Matrix()
        if (rotationDegrees != 0) matrix.postRotate(rotationDegrees.toFloat())
        if (mirror) matrix.postScale(-1f, 1f)
        return if (matrix.isIdentity) bitmap else
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    /**
     * YUV_420_888 (CameraX default) -> Bitmap, via a direct per-pixel conversion.
     * This replaces an earlier JPEG-encode/decode round trip, which was noticeably
     * slow on low-end devices (full JPEG compression just to get a Bitmap). This
     * also correctly respects each plane's rowStride/pixelStride, since many
     * devices pad camera buffers (the old code assumed no padding).
     */
    private fun ImageProxy.toBitmap(): Bitmap {
        val yPlane = planes[0]
        val uPlane = planes[1]
        val vPlane = planes[2]

        val yBuffer = yPlane.buffer
        val uBuffer = uPlane.buffer
        val vBuffer = vPlane.buffer

        val yBytes = ByteArray(yBuffer.remaining()).also { yBuffer.get(it) }
        val uBytes = ByteArray(uBuffer.remaining()).also { uBuffer.get(it) }
        val vBytes = ByteArray(vBuffer.remaining()).also { vBuffer.get(it) }

        val yRowStride = yPlane.rowStride
        val yPixelStride = yPlane.pixelStride
        val uvRowStride = uPlane.rowStride
        val uvPixelStride = uPlane.pixelStride

        val w = width
        val h = height
        val argb = IntArray(w * h)

        for (row in 0 until h) {
            val yRowStart = row * yRowStride
            val uvRow = row / 2
            val uvRowStart = uvRow * uvRowStride
            var outIndex = row * w
            for (col in 0 until w) {
                val yIndex = yRowStart + col * yPixelStride
                val uvCol = (col / 2) * uvPixelStride
                val uIndex = uvRowStart + uvCol
                val vIndex = uvRowStart + uvCol

                val y = (yBytes[yIndex].toInt() and 0xFF)
                val u = (uBytes[uIndex].toInt() and 0xFF) - 128
                val v = (vBytes[vIndex].toInt() and 0xFF) - 128

                var r = (y + 1.370705f * v).toInt()
                var g = (y - 0.337633f * u - 0.698001f * v).toInt()
                var b = (y + 1.732446f * u).toInt()

                if (r < 0) r = 0 else if (r > 255) r = 255
                if (g < 0) g = 0 else if (g > 255) g = 255
                if (b < 0) b = 0 else if (b > 255) b = 255

                argb[outIndex++] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }

        return Bitmap.createBitmap(argb, w, h, Bitmap.Config.ARGB_8888)
    }

    companion object {
        private const val TAG = "HandLandmarkerHelper"
    }
}
