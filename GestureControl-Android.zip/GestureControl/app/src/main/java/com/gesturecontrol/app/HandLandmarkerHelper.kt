package com.gesturecontrol.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.util.Log
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.io.ByteArrayOutputStream

/**
 * Direct Android equivalent of hand_tracking.py's HandTracker class, using the SAME
 * hand_landmarker.task model file bundled with the PC project (see app/src/main/assets/).
 */
class HandLandmarkerHelper(
    private val context: Context,
    private val onResult: (HandLandmarkerResult, Int, Int) -> Unit,
    private val onError: (String) -> Unit
) {
    private var handLandmarker: HandLandmarker? = null

    init {
        setup()
    }

    private fun setup() {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath("hand_landmarker.task")
                .setDelegate(Delegate.CPU)
                .build()

            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(Config.MAX_NUM_HANDS)
                .setMinHandDetectionConfidence(Config.MIN_DETECTION_CONFIDENCE)
                .setMinHandPresenceConfidence(Config.MIN_PRESENCE_CONFIDENCE)
                .setMinTrackingConfidence(Config.MIN_TRACKING_CONFIDENCE)
                .setResultListener { result, input -> onResult(result, input.width, input.height) }
                .setErrorListener { e -> onError(e.message ?: "HandLandmarker error") }
                .build()

            handLandmarker = HandLandmarker.createFromOptions(context, options)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to init HandLandmarker", e)
            onError("Failed to load model: ${e.message}")
        }
    }

    /** Feed one camera frame in. Safe to call repeatedly from the analyzer thread. */
    fun detectAsync(imageProxy: ImageProxy, rotationDegrees: Int, isFrontCamera: Boolean) {
        val landmarker = handLandmarker
        if (landmarker == null) {
            imageProxy.close()
            return
        }
        try {
            val bitmap = imageProxy.toBitmap()
            val processed = rotateAndMirror(bitmap, rotationDegrees, isFrontCamera)
            val mpImage: MPImage = BitmapImageBuilder(processed).build()
            landmarker.detectAsync(mpImage, System.currentTimeMillis())
        } catch (e: Exception) {
            Log.e(TAG, "detectAsync failed", e)
        } finally {
            imageProxy.close()
        }
    }

    fun close() {
        handLandmarker?.close()
        handLandmarker = null
    }

    private fun rotateAndMirror(bitmap: Bitmap, rotationDegrees: Int, mirror: Boolean): Bitmap {
        val matrix = Matrix()
        if (rotationDegrees != 0) matrix.postRotate(rotationDegrees.toFloat())
        if (mirror) matrix.postScale(-1f, 1f)
        return if (matrix.isIdentity) bitmap else
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    /** YUV_420_888 (CameraX default) -> Bitmap, via JPEG re-encode (simple & reliable). */
    private fun ImageProxy.toBitmap(): Bitmap {
        val yBuffer = planes[0].buffer
        val uBuffer = planes[1].buffer
        val vBuffer = planes[2].buffer

        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()

        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)

        val yuvImage = YuvImage(nv21, ImageFormat.NV21, width, height, null)
        val out = ByteArrayOutputStream()
        yuvImage.compressToJpeg(Rect(0, 0, width, height), 90, out)
        val bytes = out.toByteArray()
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    companion object {
        private const val TAG = "HandLandmarkerHelper"
    }
}
