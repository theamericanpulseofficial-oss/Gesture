package com.gesturecontrol.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.TypedValue
import android.view.View
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark

/**
 * Drawn inside a TYPE_APPLICATION_OVERLAY window that covers the whole screen,
 * so it stays visible on top of every other app.
 *
 * The cursor is a classic PC-style arrow pointer (like Windows/macOS), with the
 * hotspot (the point that actually taps/clicks) at the arrow's tip - exactly
 * like a real mouse cursor, instead of a ring/crosshair.
 *
 * IMPORTANT mirror fix: the camera bitmap is ALREADY horizontally mirrored once,
 * before it's fed to MediaPipe (see HandLandmarkerHelper.rotateAndMirror). That
 * means landmark.x()/y() here are already in "selfie-correct" space - moving
 * your real hand right increases x. Do NOT mirror again here.
 */
class CursorOverlayView(context: Context) : View(context) {

    private var landmarks: List<NormalizedLandmark> = emptyList()
    private var cursorX = -1f
    private var cursorY = -1f
    private var stateColor = Color.WHITE

    private val density = context.resources.displayMetrics.density

    private val pointPaint = Paint().apply {
        color = Color.parseColor("#00E676")
        style = Paint.Style.FILL
        isAntiAlias = true
        alpha = 160
    }
    private val linePaint = Paint().apply {
        color = Color.parseColor("#00E676")
        style = Paint.Style.STROKE
        strokeWidth = 4f
        isAntiAlias = true
        alpha = 140
    }

    // Classic arrow-pointer shape, tip (hotspot) at local (0,0).
    private val arrowPath = Path()
    private val arrowFillPaint = Paint().apply {
        style = Paint.Style.FILL
        isAntiAlias = true
    }
    private val arrowOutlinePaint = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 1.6f * density
        isAntiAlias = true
        strokeJoin = Paint.Join.ROUND
    }
    private val shadowPaint = Paint().apply {
        color = Color.argb(60, 0, 0, 0)
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    init {
        buildArrowPath()
    }

    private fun buildArrowPath() {
        // Standard mouse-pointer silhouette, scaled by screen density.
        val s = density
        arrowPath.reset()
        arrowPath.moveTo(0f, 0f)
        arrowPath.lineTo(0f, 22f * s)
        arrowPath.lineTo(5.5f * s, 17.2f * s)
        arrowPath.lineTo(9f * s, 25.5f * s)
        arrowPath.lineTo(12.7f * s, 23.8f * s)
        arrowPath.lineTo(9.3f * s, 15.6f * s)
        arrowPath.lineTo(16.5f * s, 15.6f * s)
        arrowPath.close()
    }

    private val connections = listOf(
        0 to 1, 1 to 2, 2 to 3, 3 to 4,
        0 to 5, 5 to 6, 6 to 7, 7 to 8,
        5 to 9, 9 to 10, 10 to 11, 11 to 12,
        9 to 13, 13 to 14, 14 to 15, 15 to 16,
        13 to 17, 17 to 18, 18 to 19, 19 to 20,
        0 to 17, 5 to 9, 9 to 13, 13 to 17
    )

    /**
     * @param newLandmarks raw normalized landmarks (already mirror-corrected upstream)
     * @param cursorScreenX / cursorScreenY palm-center position in real screen pixels -
     *        this is where the arrow's TIP (hotspot) is placed, matching where taps land.
     * @param color current gesture state color (tints the arrow fill)
     */
    fun update(
        newLandmarks: List<NormalizedLandmark>,
        cursorScreenX: Float,
        cursorScreenY: Float,
        color: Int
    ) {
        landmarks = newLandmarks
        cursorX = cursorScreenX
        cursorY = cursorScreenY
        stateColor = color
        postInvalidate()
    }

    fun clear() {
        landmarks = emptyList()
        cursorX = -1f
        cursorY = -1f
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Skeleton: drawn directly from normalized coords * this view's size (subtle,
        // just for feedback - the arrow above is the real "cursor").
        if (landmarks.isNotEmpty()) {
            fun px(nx: Float) = nx * width
            fun py(ny: Float) = ny * height

            for ((a, b) in connections) {
                if (a < landmarks.size && b < landmarks.size) {
                    canvas.drawLine(
                        px(landmarks[a].x()), py(landmarks[a].y()),
                        px(landmarks[b].x()), py(landmarks[b].y()),
                        linePaint
                    )
                }
            }
            for (lm in landmarks) {
                canvas.drawCircle(px(lm.x()), py(lm.y()), 5f, pointPaint)
            }
        }

        // PC-style arrow cursor, hotspot (tip) exactly at the palm-center point.
        if (cursorX >= 0f && cursorY >= 0f) {
            canvas.save()
            canvas.translate(cursorX, cursorY)

            // soft drop shadow, offset slightly, so it's visible on any background
            canvas.save()
            canvas.translate(2f * density, 3f * density)
            canvas.drawPath(arrowPath, shadowPaint)
            canvas.restore()

            arrowFillPaint.color = stateColor
            canvas.drawPath(arrowPath, arrowFillPaint)
            canvas.drawPath(arrowPath, arrowOutlinePaint)

            canvas.restore()
        }
    }
}
