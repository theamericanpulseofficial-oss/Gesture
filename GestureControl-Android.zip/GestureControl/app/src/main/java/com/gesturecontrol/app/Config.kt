package com.gesturecontrol.app

/**
 * Tunable knobs, ported from the PC project's config.py and extended for the
 * background / system-wide Android behaviour (drag, 4-direction scroll, palm cursor).
 */
object Config {

    // Hand detection (same defaults as config.py)
    const val MIN_DETECTION_CONFIDENCE = 0.7f
    const val MIN_TRACKING_CONFIDENCE = 0.5f
    const val MIN_PRESENCE_CONFIDENCE = 0.5f
    const val MAX_NUM_HANDS = 2

    // Palm center = average of these landmark indices (wrist + 4 knuckles).
    // Much more stable than the fingertip, since it barely moves during a pinch/fist.
    val PALM_LANDMARK_IDS = intArrayOf(0, 5, 9, 13, 17)

    // Pinch (click) threshold: SCALE-INVARIANT now, relative to the hand's own size
    // (distance from wrist to middle-knuckle), so it doesn't misfire when your hand
    // is closer/farther from the camera. Old fixed-pixel threshold caused false clicks.
    const val PINCH_THRESHOLD_RATIO = 0.32f

    // Debounce / cooldowns (ms) -> equivalent of GESTURE_COOLDOWN / CLICK_HOLD_TIME
    const val CLICK_HOLD_MS = 150L
    const val GESTURE_COOLDOWN_MS = 500L

    // A detected gesture must repeat for this many consecutive frames before it's
    // allowed to fire a one-shot action (tap / long-press / starting a drag). This
    // filters out single noisy frames that used to cause accidental clicks.
    const val GESTURE_CONFIRM_FRAMES = 3

    // Exponential smoothing applied to the palm position before it moves the cursor.
    // Lower = smoother but more lag, higher = snappier but more jitter.
    const val CURSOR_SMOOTHING_ALPHA = 0.45f

    // Camera resolution - kept modest so low-end devices can still run this smoothly.
    const val CAMERA_WIDTH = 480
    const val CAMERA_HEIGHT = 360

    // Scroll -> equivalent of SCROLL_SPEED / GESTURE_TIMEOUT. Works for all 4 directions;
    // whichever axis (x or y) moved further past its threshold wins for that tick.
    const val SCROLL_MOVE_THRESHOLD = 0.035f   // min normalized delta to register a scroll tick
    const val SCROLL_COOLDOWN_MS = 350L
    const val SCROLL_SWIPE_DISTANCE_PX = 500   // how far the simulated swipe travels on screen

    // Long press (right-click equivalent)
    const val LONG_PRESS_DURATION_MS = 500L

    // Drag & drop (fist + movement)
    const val DRAG_MIN_MOVE_PX = 6f         // ignore jitter smaller than this between drag steps
    const val DRAG_SEGMENT_DURATION_MS = 80L

    // Safety
    const val FAILSAFE_MIN_FPS = 8

    // Foreground service / notification
    const val NOTIFICATION_CHANNEL_ID = "gesture_control_channel"
    const val NOTIFICATION_ID = 1001

    // Cursor sensitivity (relative/"mouse" movement mode, like PC mouse DPI).
    // 1.0 = fairly small hand movements needed; adjustable in-app.
    const val PREFS_NAME = "gesture_prefs"
    const val PREF_SENSITIVITY = "cursor_sensitivity"
    const val DEFAULT_SENSITIVITY = 1.6f
    const val MIN_SENSITIVITY = 0.5f
    const val MAX_SENSITIVITY = 3.5f

    // Two-hand pinch-to-zoom
    const val ZOOM_BASE_SEPARATION_PX = 300f
    const val ZOOM_MIN_SEPARATION_PX = 40f
    const val ZOOM_MAX_SEPARATION_PX = 1000f
}
