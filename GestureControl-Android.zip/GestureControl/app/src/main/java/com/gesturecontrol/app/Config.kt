package com.gesturecontrol.app

/**
 * Same tunable knobs as the PC project's config.py, adapted to Android.
 * Distances here are NORMALIZED (0.0 - 1.0, relative to the camera frame)
 * instead of pixels, because phone camera resolutions vary a lot.
 */
object Config {

    // Hand detection (same defaults as config.py)
    const val MIN_DETECTION_CONFIDENCE = 0.7f
    const val MIN_TRACKING_CONFIDENCE = 0.5f
    const val MIN_PRESENCE_CONFIDENCE = 0.5f
    const val MAX_NUM_HANDS = 1

    // Pinch (click) thresholds -> equivalent of CLICK_DISTANCE_THRESHOLD (60px @ 640 wide ~= 0.09)
    const val PINCH_THRESHOLD = 0.09f

    // Debounce / cooldowns (ms) -> equivalent of GESTURE_COOLDOWN / CLICK_HOLD_TIME
    const val CLICK_HOLD_MS = 150L
    const val GESTURE_COOLDOWN_MS = 500L

    // Scroll -> equivalent of SCROLL_SPEED / GESTURE_TIMEOUT
    const val SCROLL_MOVE_THRESHOLD = 0.035f   // min normalized vertical delta to register a scroll tick
    const val SCROLL_COOLDOWN_MS = 350L
    const val SCROLL_SWIPE_DISTANCE_PX = 500   // how far the simulated swipe travels on screen

    // Long press (right-click equivalent)
    const val LONG_PRESS_DURATION_MS = 500L

    // Safety
    const val FAILSAFE_MIN_FPS = 8
}
