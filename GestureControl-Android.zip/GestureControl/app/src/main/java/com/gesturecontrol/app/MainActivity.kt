package com.gesturecontrol.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.util.Size
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.gesturecontrol.app.databinding.ActivityMainBinding
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Android equivalent of gesture_v3/core/system.py's SystemController: owns the
 * camera loop, feeds frames to the hand tracker, classifies the gesture every
 * frame, and drives the accessibility service the same way the PC main loop
 * drove pyautogui.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private var handLandmarkerHelper: HandLandmarkerHelper? = null
    private val gestureClassifier = GestureClassifier()

    private var isRunning = false
    private var cameraProvider: ProcessCameraProvider? = null

    // --- Gesture state (mirrors mouse_control.py's stateful smoothing/cooldowns) ---
    private var lastActionTime = 0L
    private var lastScrollY: Float? = null
    private var lastScrollTime = 0L

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else
                binding.statusText.text = "Camera permission denied"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.btnEnableAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnStartStop.setOnClickListener {
            if (!isRunning) requestCameraAndStart() else stopEverything()
        }
    }

    private fun requestCameraAndStart() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)
            == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            requestPermissionLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        if (!GestureAccessibilityService.isRunning) {
            binding.statusText.text = "Enable Accessibility first!"
        }

        handLandmarkerHelper = HandLandmarkerHelper(
            context = this,
            onResult = { result, w, h -> runOnUiThread { onHandResult(result, w, h) } },
            onError = { msg -> runOnUiThread { binding.statusText.text = "Error: $msg" } }
        )

        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }

            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor) { imageProxy ->
                        handLandmarkerHelper?.detectAsync(
                            imageProxy,
                            imageProxy.imageInfo.rotationDegrees,
                            isFrontCamera = true
                        )
                    }
                }

            val selector = CameraSelector.DEFAULT_FRONT_CAMERA

            try {
                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(this, selector, preview, analysis)
                isRunning = true
                binding.btnStartStop.text = "Stop"
            } catch (e: Exception) {
                Log.e(TAG, "Camera bind failed", e)
                binding.statusText.text = "Camera bind failed: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopEverything() {
        cameraProvider?.unbindAll()
        handLandmarkerHelper?.close()
        handLandmarkerHelper = null
        isRunning = false
        binding.btnStartStop.text = "Start"
        binding.statusText.text = "STOPPED"
        binding.overlayView.update(emptyList(), true, Color.RED)
    }

    /** Equivalent of the PC main loop body: classify -> act -> draw. */
    private fun onHandResult(result: HandLandmarkerResult, imgW: Int, imgH: Int) {
        val hands = result.landmarks()
        val landmarks: List<NormalizedLandmark> = if (hands.isNotEmpty()) hands[0] else emptyList()

        val gestureResult = gestureClassifier.detectGesture(landmarks)
        val now = System.currentTimeMillis()

        val screenW = resources.displayMetrics.widthPixels.toFloat()
        val screenH = resources.displayMetrics.heightPixels.toFloat()

        var stateColor = Color.WHITE
        var statusLabel = "NEUTRAL"

        val indexTip = landmarks.getOrNull(8)
        // Front camera preview is mirrored, so mirror x when mapping to screen coords too.
        val screenX = indexTip?.let { (1f - it.x()) * screenW }
        val screenY = indexTip?.let { it.y() * screenH }

        val service = GestureAccessibilityService.instance

        when (gestureResult.gesture) {
            Gesture.PAUSE -> {
                stateColor = Color.RED
                statusLabel = "PAUSED"
                lastScrollY = null
            }
            Gesture.TAP -> {
                stateColor = Color.rgb(255, 152, 0) // orange, pending/click
                statusLabel = "TAP"
                if (service != null && screenX != null && screenY != null &&
                    now - lastActionTime > Config.GESTURE_COOLDOWN_MS
                ) {
                    service.performTap(screenX, screenY)
                    lastActionTime = now
                }
            }
            Gesture.LONG_PRESS -> {
                stateColor = Color.MAGENTA
                statusLabel = "LONG PRESS"
                if (service != null && screenX != null && screenY != null &&
                    now - lastActionTime > Config.GESTURE_COOLDOWN_MS
                ) {
                    service.performLongPress(screenX, screenY)
                    lastActionTime = now
                }
            }
            Gesture.SCROLL -> {
                stateColor = Color.CYAN
                statusLabel = "SCROLL"
                val currentY = indexTip?.y()
                if (currentY != null) {
                    val refY = lastScrollY
                    if (refY == null) {
                        lastScrollY = currentY
                    } else {
                        val delta = currentY - refY
                        if (kotlin.math.abs(delta) > Config.SCROLL_MOVE_THRESHOLD &&
                            now - lastScrollTime > Config.SCROLL_COOLDOWN_MS
                        ) {
                            // Hand moving up (delta < 0) -> scroll content up, matching the PC version.
                            val direction = if (delta < 0) 1 else -1
                            service?.performScroll(screenW / 2f, screenH / 2f, direction)
                            lastScrollTime = now
                            lastScrollY = currentY
                        }
                    }
                }
            }
            Gesture.MOVE -> {
                stateColor = Color.GREEN
                statusLabel = "TRACKING"
                lastScrollY = null
            }
            Gesture.NEUTRAL -> {
                stateColor = Color.WHITE
                statusLabel = "NEUTRAL"
                lastScrollY = null
            }
        }

        if (!GestureAccessibilityService.isRunning) {
            statusLabel = "$statusLabel (enable accessibility!)"
        }

        binding.statusText.text = statusLabel
        binding.overlayView.update(landmarks, true, stateColor)
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        handLandmarkerHelper?.close()
    }

    companion object {
        private const val TAG = "MainActivity"
    }
}
