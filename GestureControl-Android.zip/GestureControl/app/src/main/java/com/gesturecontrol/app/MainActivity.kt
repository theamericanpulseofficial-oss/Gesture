package com.gesturecontrol.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.gesturecontrol.app.databinding.ActivityMainBinding

/**
 * Just a control panel now: request the two permissions (overlay + accessibility)
 * and start/stop the background GestureTrackingService. All the actual camera /
 * gesture / cursor work happens in the Service so it keeps running on top of
 * other apps after you leave this Activity.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val requestCameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startTrackingService() else
                binding.statusText.text = "Camera permission denied"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnEnableOverlay.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        binding.btnEnableAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnStartStop.setOnClickListener {
            if (GestureTrackingService.isRunning) stopTrackingService() else beginStartFlow()
        }

        binding.btnSkipTest.setOnClickListener {
            startActivity(Intent(this, TestActivity::class.java))
        }

        setupSensitivitySeekBar()
    }

    private fun setupSensitivitySeekBar() {
        val prefs = getSharedPreferences(Config.PREFS_NAME, MODE_PRIVATE)
        val range = Config.MAX_SENSITIVITY - Config.MIN_SENSITIVITY

        fun sensitivityFromProgress(progress: Int) =
            Config.MIN_SENSITIVITY + (progress / 30f) * range

        fun progressFromSensitivity(value: Float) =
            (((value - Config.MIN_SENSITIVITY) / range) * 30f).toInt().coerceIn(0, 30)

        val savedSensitivity = prefs.getFloat(Config.PREF_SENSITIVITY, Config.DEFAULT_SENSITIVITY)
        binding.sensitivitySeekBar.progress = progressFromSensitivity(savedSensitivity)
        binding.sensitivityLabel.text = "Cursor Sensitivity: %.1fx".format(savedSensitivity)

        binding.sensitivitySeekBar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                val value = sensitivityFromProgress(progress)
                binding.sensitivityLabel.text = "Cursor Sensitivity: %.1fx".format(value)
                if (fromUser) {
                    prefs.edit().putFloat(Config.PREF_SENSITIVITY, value).apply()
                }
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun beginStartFlow() {
        if (!Settings.canDrawOverlays(this)) {
            binding.statusText.text = "Please allow 'Display over other apps' first"
            return
        }
        if (!isAccessibilityServiceEnabled()) {
            binding.statusText.text = "Please enable the Accessibility Service first"
            return
        }
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)
            == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            startTrackingService()
        } else {
            requestCameraPermission.launch(android.Manifest.permission.CAMERA)
        }
    }

    private fun startTrackingService() {
        val intent = Intent(this, GestureTrackingService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        refreshStatus()
    }

    private fun stopTrackingService() {
        val intent = Intent(this, GestureTrackingService::class.java).apply {
            action = GestureTrackingService.ACTION_STOP
        }
        startService(intent)
        refreshStatus()
    }

    private fun refreshStatus() {
        val running = GestureTrackingService.isRunning
        binding.btnStartStop.text = if (running) "Stop" else "3. Start"
        binding.statusText.text = if (running)
            "Service: Running - minimize this app and try your hand gestures"
        else
            "Service: Stopped"
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponent = "$packageName/${GestureAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expectedComponent, ignoreCase = true)) return true
        }
        return false
    }
}
