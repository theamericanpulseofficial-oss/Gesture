package com.gesturecontrol.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.util.Log
import android.util.Size
import android.view.Gravity
import android.view.WindowManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Android equivalent of gesture_v3/core/system.py's SystemController, but running
 * as a background foreground Service (not tied to any Activity/UI) so it keeps
 * working - camera + gesture control + overlay cursor - even while the user is
 * inside a completely different app. This is what makes it "system-wide" like
 * the PC version controlling the whole desktop.
 */
class GestureTrackingService : LifecycleService() {

    private lateinit var cameraExecutor: ExecutorService
    private var handLandmarkerHelper: HandLandmarkerHelper? = null
    private val gestureClassifier = GestureClassifier()
    private var cameraProvider: ProcessCameraProvider? = null

    private lateinit var windowManager: WindowManager
    private var overlayView: CursorOverlayView? = null

    private var screenW = 0f
    private var screenH = 0f

    // --- Gesture state ---
    private var lastActionTime = 0L
    private var lastScrollX: Float? = null
    private var lastScrollY: Float? = null
    private var lastScrollTime = 0L
    private var isDragging = false
    private var lastDragX = 0f
    private var lastDragY = 0f

    override fun onCreate() {
        super.onCreate()
        instance = this
        cameraExecutor = Executors.newSingleThreadExecutor()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val metrics = resources.displayMetrics
        screenW = metrics.widthPixels.toFloat()
        screenH = metrics.heightPixels.toFloat()

        startForegroundWithNotification()
        addOverlay()
        startCamera()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
        }
        return START_STICKY
    }

    // ----------------- Notification / foreground -----------------

    private fun startForegroundWithNotification() {
        val channelId = Config.NOTIFICATION_CHANNEL_ID
        val channel = NotificationChannel(
            channelId, "Gesture Control", NotificationManager.IMPORTANCE_LOW
        )
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)

        val stopIntent = Intent(this, GestureTrackingService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Gesture Control running")
            .setContentText("Watching your hand to control the screen")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .addAction(0, "Stop", stopPendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(Config.NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(Config.NOTIFICATION_ID, notification)
        }
    }

    // ----------------- Overlay window (cursor + skeleton, system-wide) -----------------

    private fun addOverlay() {
        val view = CursorOverlayView(this)
        overlayView = view

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        try {
            windowManager.addView(view, params)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to add overlay - was 'Draw over other apps' permission granted?", e)
        }
    }

    private fun removeOverlay() {
        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        overlayView = null
    }

    // ----------------- Camera -----------------

    private fun startCamera() {
        handLandmarkerHelper = HandLandmarkerHelper(
            context = this,
            onResult = { result, w, h -> onHandResult(result, w, h) },
            onError = { msg -> Log.e(TAG, "HandLandmarker error: $msg") }
        )

        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()

            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor) { imageProxy ->
                        handLandmarkerHelper?.detectAsync(
                            imageProxy,
                            imageProxy.imageInfo.rotationDegrees,
                            isFrontCamera = true
                        )
                    }
                }

            try {
                cameraProvider?.unbindAll()
                // LifecycleService is itself a LifecycleOwner, so CameraX can run
                // headless in the background, with no Preview/UI needed at all.
                cameraProvider?.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                Log.e(TAG, "Camera bind failed", e)
            }
        }, androidx.core.content.ContextCompat.getMainExecutor(this))
    }

    // ----------------- Gesture state machine (equivalent of the PC main loop) -----------------

    private fun onHandResult(result: HandLandmarkerResult, imgW: Int, imgH: Int) {
        val hands = result.landmarks()
        val landmarks: List<NormalizedLandmark> = if (hands.isNotEmpty()) hands[0] else emptyList()

        if (landmarks.isEmpty()) {
            // Hand lost -> safety: end any in-progress drag, clear the overlay.
            if (isDragging) {
                GestureAccessibilityService.instance?.endDrag(lastDragX, lastDragY)
                isDragging = false
            }
            lastScrollX = null
            lastScrollY = null
            overlayView?.clear()
            return
        }

        val palm = gestureClassifier.palmCenter(landmarks) ?: return
        // No extra mirroring here: the bitmap was already mirrored before detection
        // (see HandLandmarkerHelper), so palm.x/y map straight onto the screen.
        val cursorX = palm.x * screenW
        val cursorY = palm.y * screenH

        val gestureResult = gestureClassifier.detectGesture(landmarks)
        val now = System.currentTimeMillis()
        val service = GestureAccessibilityService.instance

        var color = Color.WHITE

        when (gestureResult.gesture) {
            Gesture.TAP -> {
                color = Color.parseColor("#FF9800") // orange
                if (isDragging) {
                    service?.endDrag(lastDragX, lastDragY)
                    isDragging = false
                }
                if (service != null && now - lastActionTime > Config.GESTURE_COOLDOWN_MS) {
                    service.performTap(cursorX, cursorY)
                    lastActionTime = now
                }
            }

            Gesture.LONG_PRESS -> {
                color = Color.MAGENTA
                if (isDragging) {
                    service?.endDrag(lastDragX, lastDragY)
                    isDragging = false
                }
                if (service != null && now - lastActionTime > Config.GESTURE_COOLDOWN_MS) {
                    service.performLongPress(cursorX, cursorY)
                    lastActionTime = now
                }
            }

            Gesture.FIST -> {
                color = Color.RED
                if (service != null) {
                    if (!isDragging) {
                        service.startDrag(cursorX, cursorY)
                        isDragging = true
                        lastDragX = cursorX
                        lastDragY = cursorY
                    } else {
                        val moved = kotlin.math.hypot(
                            (cursorX - lastDragX).toDouble(),
                            (cursorY - lastDragY).toDouble()
                        )
                        if (moved > Config.DRAG_MIN_MOVE_PX) {
                            service.continueDrag(lastDragX, lastDragY, cursorX, cursorY)
                            lastDragX = cursorX
                            lastDragY = cursorY
                        }
                    }
                }
                lastScrollX = null
                lastScrollY = null
            }

            Gesture.SCROLL -> {
                color = Color.CYAN
                if (isDragging) {
                    service?.endDrag(lastDragX, lastDragY)
                    isDragging = false
                }
                val refX = lastScrollX
                val refY = lastScrollY
                if (refX == null || refY == null) {
                    lastScrollX = cursorX
                    lastScrollY = cursorY
                } else if (now - lastScrollTime > Config.SCROLL_COOLDOWN_MS) {
                    val dxNorm = palm.x - (refX / screenW)
                    val dyNorm = palm.y - (refY / screenH)
                    val absDx = kotlin.math.abs(dxNorm)
                    val absDy = kotlin.math.abs(dyNorm)

                    if (absDx > Config.SCROLL_MOVE_THRESHOLD || absDy > Config.SCROLL_MOVE_THRESHOLD) {
                        if (absDy >= absDx) {
                            // vertical wins: hand moved up -> direction 1, down -> -1
                            val direction = if (dyNorm < 0) 1 else -1
                            service?.performScroll(screenW / 2f, screenH / 2f, ScrollAxis.VERTICAL, direction)
                        } else {
                            // horizontal wins: hand moved left -> direction 1, right -> -1
                            val direction = if (dxNorm < 0) 1 else -1
                            service?.performScroll(screenW / 2f, screenH / 2f, ScrollAxis.HORIZONTAL, direction)
                        }
                        lastScrollTime = now
                        lastScrollX = cursorX
                        lastScrollY = cursorY
                    }
                }
            }

            Gesture.NEUTRAL -> {
                color = Color.WHITE // normal idle pointer, just like a PC cursor
                if (isDragging) {
                    service?.endDrag(lastDragX, lastDragY)
                    isDragging = false
                }
                lastScrollX = null
                lastScrollY = null
            }
        }

        overlayView?.update(landmarks, cursorX, cursorY, color)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isDragging) {
            GestureAccessibilityService.instance?.endDrag(lastDragX, lastDragY)
        }
        cameraProvider?.unbindAll()
        handLandmarkerHelper?.close()
        cameraExecutor.shutdown()
        removeOverlay()
        instance = null
    }

    companion object {
        private const val TAG = "GestureTrackingService"
        const val ACTION_STOP = "com.gesturecontrol.app.ACTION_STOP"

        @Volatile
        var instance: GestureTrackingService? = null
            private set

        val isRunning: Boolean
            get() = instance != null
    }
}
