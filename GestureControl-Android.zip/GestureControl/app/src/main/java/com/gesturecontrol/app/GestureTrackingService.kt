package com.gesturecontrol.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.util.Log
import android.util.Size
import android.view.Gravity
import android.view.WindowManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Android equivalent of gesture_v3/core/system.py's SystemController, running as a
 * background foreground Service so camera + gesture control + overlay cursor keep
 * working while the user is inside a different app. This is the system-wide layer.
 */
class GestureTrackingService : LifecycleService() {

    private lateinit var cameraExecutor: ExecutorService
    private var handLandmarkerHelper: HandLandmarkerHelper? = null
    private val gestureClassifier = GestureClassifier()
    private var cameraProvider: ProcessCameraProvider? = null

    private lateinit var windowManager: WindowManager
    private var overlayView: CursorOverlayView? = null

    private var screenW = 0f
    private var screenH = 0f
    private var sensitivity = Config.DEFAULT_SENSITIVITY
    private var prefsListener: android.content.SharedPreferences.OnSharedPreferenceChangeListener? = null

    // --- Relative "mouse" cursor state (like PC mouse DPI: moves by DELTA, not
    // by an absolute hand position, so sensitivity has something to scale). ---
    private var cursorX = 0f
    private var cursorY = 0f
    private var hasPrevPalm = false
    private var prevPalmX = 0f
    private var prevPalmY = 0f

    // --- Gesture state ---
    private var lastActionTime = 0L
    private var lastScrollX: Float? = null
    private var lastScrollY: Float? = null
    private var lastScrollTime = 0L
    private var isDragging = false
    private var lastDragX = 0f
    private var lastDragY = 0f

    // --- Two-hand zoom state ---
    private var isZooming = false
    private var zoomBaselineHandDist = 0f
    private var zoomT1x = 0f
    private var zoomT1y = 0f
    private var zoomT2x = 0f
    private var zoomT2y = 0f

    override fun onCreate() {
        super.onCreate()
        instance = this
        cameraExecutor = Executors.newSingleThreadExecutor()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val metrics = resources.displayMetrics
        screenW = metrics.widthPixels.toFloat()
        screenH = metrics.heightPixels.toFloat()
        cursorX = screenW / 2f
        cursorY = screenH / 2f

        val prefs = getSharedPreferences(Config.PREFS_NAME, Context.MODE_PRIVATE)
        sensitivity = prefs.getFloat(Config.PREF_SENSITIVITY, Config.DEFAULT_SENSITIVITY)
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { p, key ->
            if (key == Config.PREF_SENSITIVITY) {
                sensitivity = p.getFloat(Config.PREF_SENSITIVITY, Config.DEFAULT_SENSITIVITY)
            }
        }
        prefsListener = listener
        prefs.registerOnSharedPreferenceChangeListener(listener)

        startForegroundWithNotification()
        addOverlay()
        startCamera()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
        }
        return START_STICKY
    }

    // ----------------- Notification / foreground -----------------

    private fun startForegroundWithNotification() {
        val channelId = Config.NOTIFICATION_CHANNEL_ID
        val channel = NotificationChannel(
            channelId, "Gesture Control", NotificationManager.IMPORTANCE_LOW
        )
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)

        val stopIntent = Intent(this, GestureTrackingService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Gesture Control running")
            .setContentText("Watching your hand to control the screen")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .addAction(0, "Stop", stopPendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(Config.NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(Config.NOTIFICATION_ID, notification)
        }
    }

    // ----------------- Overlay window (cursor ONLY, system-wide - no skeleton) -----------------

    private fun addOverlay() {
        val view = CursorOverlayView(this)
        view.showSkeleton = false // system-wide overlay: cursor only, per user request
        overlayView = view

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        try {
            windowManager.addView(view, params)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to add overlay - was 'Draw over other apps' permission granted?", e)
        }
    }

    private fun removeOverlay() {
        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        overlayView = null
    }

    // ----------------- Camera -----------------

    private fun startCamera() {
        handLandmarkerHelper = HandLandmarkerHelper(
            context = this,
            onResult = { result, w, h -> onHandResult(result) },
            onError = { msg -> Log.e(TAG, "HandLandmarker error: $msg") }
        )

        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()

            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor) { imageProxy ->
                        handLandmarkerHelper?.detectAsync(
                            imageProxy,
                            imageProxy.imageInfo.rotationDegrees,
                            isFrontCamera = true
                        )
                    }
                }

            try {
                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                Log.e(TAG, "Camera bind failed", e)
            }
        }, androidx.core.content.ContextCompat.getMainExecutor(this))
    }

    // ----------------- Gesture state machine -----------------

    private fun onHandResult(result: HandLandmarkerResult) {
        val handsList = result.landmarks()

        if (handsList.size >= 2) {
            endDragIfNeeded()
            lastScrollX = null
            lastScrollY = null
            hasPrevPalm = false
            handleTwoHandZoom(handsList[0], handsList[1])
            overlayView?.clear() // no single cursor while zooming with two hands
            return
        }

        if (isZooming) {
            GestureAccessibilityService.instance?.endPinch(zoomT1x, zoomT1y, zoomT2x, zoomT2y)
            isZooming = false
        }

        val landmarks: List<NormalizedLandmark> = if (handsList.isNotEmpty()) handsList[0] else emptyList()

        if (landmarks.isEmpty()) {
            endDragIfNeeded()
            lastScrollX = null
            lastScrollY = null
            hasPrevPalm = false
            overlayView?.clear()
            return
        }

        val palm = gestureClassifier.palmCenter(landmarks) ?: return

        // Relative cursor movement: cursor moves by (hand delta * sensitivity),
        // like a real mouse - not by mapping the hand's absolute position.
        if (!hasPrevPalm) {
            prevPalmX = palm.x
            prevPalmY = palm.y
            hasPrevPalm = true
        } else {
            val dx = (palm.x - prevPalmX) * sensitivity * screenW
            val dy = (palm.y - prevPalmY) * sensitivity * screenH
            cursorX = (cursorX + dx).coerceIn(0f, screenW)
            cursorY = (cursorY + dy).coerceIn(0f, screenH)
            prevPalmX = palm.x
            prevPalmY = palm.y
        }

        val gestureResult = gestureClassifier.detectGesture(landmarks)
        val now = System.currentTimeMillis()
        val service = GestureAccessibilityService.instance

        var color = Color.WHITE

        when (gestureResult.gesture) {
            Gesture.TAP -> {
                color = Color.parseColor("#FF9800")
                endDragIfNeeded()
                // Click lands EXACTLY at the cursor tip (cursorX, cursorY) - the
                // same point the arrow is drawn at, so it matches a real PC pointer.
                if (service != null && now - lastActionTime > Config.GESTURE_COOLDOWN_MS) {
                    service.performTap(cursorX, cursorY)
                    lastActionTime = now
                }
            }

            Gesture.LONG_PRESS -> {
                color = Color.MAGENTA
                endDragIfNeeded()
                if (service != null && now - lastActionTime > Config.GESTURE_COOLDOWN_MS) {
                    service.performLongPress(cursorX, cursorY)
                    lastActionTime = now
                }
            }

            Gesture.FIST -> {
                color = Color.RED
                if (service != null) {
                    if (!isDragging) {
                        service.startDrag(cursorX, cursorY)
                        isDragging = true
                        lastDragX = cursorX
                        lastDragY = cursorY
                    } else {
                        val moved = hypot((cursorX - lastDragX).toDouble(), (cursorY - lastDragY).toDouble())
                        if (moved > Config.DRAG_MIN_MOVE_PX) {
                            service.continueDrag(lastDragX, lastDragY, cursorX, cursorY)
                            lastDragX = cursorX
                            lastDragY = cursorY
                        }
                    }
                }
                lastScrollX = null
                lastScrollY = null
            }

            Gesture.SCROLL -> {
                color = Color.CYAN
                endDragIfNeeded()
                val refX = lastScrollX
                val refY = lastScrollY
                if (refX == null || refY == null) {
                    lastScrollX = cursorX
                    lastScrollY = cursorY
                } else if (now - lastScrollTime > Config.SCROLL_COOLDOWN_MS) {
                    val dxNorm = (cursorX - refX) / screenW
                    val dyNorm = (cursorY - refY) / screenH
                    val absDx = kotlin.math.abs(dxNorm)
                    val absDy = kotlin.math.abs(dyNorm)

                    if (absDx > Config.SCROLL_MOVE_THRESHOLD || absDy > Config.SCROLL_MOVE_THRESHOLD) {
                        if (absDy >= absDx) {
                            val direction = if (dyNorm < 0) 1 else -1
                            service?.performScroll(screenW / 2f, screenH / 2f, ScrollAxis.VERTICAL, direction)
                        } else {
                            val direction = if (dxNorm < 0) 1 else -1
                            service?.performScroll(screenW / 2f, screenH / 2f, ScrollAxis.HORIZONTAL, direction)
                        }
                        lastScrollTime = now
                        lastScrollX = cursorX
                        lastScrollY = cursorY
                    }
                }
            }

            Gesture.NEUTRAL -> {
                // Open hand, no specific pose -> just tracking, like a PC pointer sitting still.
                color = Color.WHITE
                endDragIfNeeded()
                lastScrollX = null
                lastScrollY = null
            }
        }

        overlayView?.update(landmarks, cursorX, cursorY, color)
    }

    private fun endDragIfNeeded() {
        if (isDragging) {
            GestureAccessibilityService.instance?.endDrag(lastDragX, lastDragY)
            isDragging = false
        }
    }

    /**
     * Two-hand pinch-to-zoom. Per the requested mapping: hands moving CLOSER
     * together -> zoom IN; hands moving FARTHER apart -> zoom OUT. We dispatch
     * two real synthetic touch points whose separation moves the OPPOSITE way
     * of the real hand separation, since a standard OS pinch gesture (touch
     * points spreading apart) is what apps interpret as "zoom in".
     */
    private fun handleTwoHandZoom(handA: List<NormalizedLandmark>, handB: List<NormalizedLandmark>) {
        val palmA = gestureClassifier.palmCenter(handA) ?: return
        val palmB = gestureClassifier.palmCenter(handB) ?: return

        val ax = palmA.x * screenW
        val ay = palmA.y * screenH
        val bx = palmB.x * screenW
        val by = palmB.y * screenH

        val handDist = hypot((ax - bx).toDouble(), (ay - by).toDouble()).toFloat()
        val angle = atan2((by - ay).toDouble(), (bx - ax).toDouble())
        val cx = screenW / 2f
        val cy = screenH / 2f
        val service = GestureAccessibilityService.instance

        if (!isZooming) {
            isZooming = true
            zoomBaselineHandDist = handDist
            val half = Config.ZOOM_BASE_SEPARATION_PX / 2f
            zoomT1x = cx - (half * cos(angle)).toFloat()
            zoomT1y = cy - (half * sin(angle)).toFloat()
            zoomT2x = cx + (half * cos(angle)).toFloat()
            zoomT2y = cy + (half * sin(angle)).toFloat()
            service?.startPinch(zoomT1x, zoomT1y, zoomT2x, zoomT2y)
        } else {
            val deltaHandDist = handDist - zoomBaselineHandDist
            // Hands closer (delta negative) -> bigger synthetic separation -> zoom in.
            // Hands farther (delta positive) -> smaller synthetic separation -> zoom out.
            val newSeparation = (Config.ZOOM_BASE_SEPARATION_PX - deltaHandDist)
                .coerceIn(Config.ZOOM_MIN_SEPARATION_PX, Config.ZOOM_MAX_SEPARATION_PX)
            val half = newSeparation / 2f
            val newT1x = cx - (half * cos(angle)).toFloat()
            val newT1y = cy - (half * sin(angle)).toFloat()
            val newT2x = cx + (half * cos(angle)).toFloat()
            val newT2y = cy + (half * sin(angle)).toFloat()

            service?.continuePinch(zoomT1x, zoomT1y, newT1x, newT1y, zoomT2x, zoomT2y, newT2x, newT2y)
            zoomT1x = newT1x; zoomT1y = newT1y
            zoomT2x = newT2x; zoomT2y = newT2y
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        prefsListener?.let {
            getSharedPreferences(Config.PREFS_NAME, Context.MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(it)
        }
        endDragIfNeeded()
        if (isZooming) {
            GestureAccessibilityService.instance?.endPinch(zoomT1x, zoomT1y, zoomT2x, zoomT2y)
        }
        cameraProvider?.unbindAll()
        handLandmarkerHelper?.close()
        cameraExecutor.shutdown()
        removeOverlay()
        instance = null
    }

    companion object {
        private const val TAG = "GestureTrackingService"
        const val ACTION_STOP = "com.gesturecontrol.app.ACTION_STOP"

        @Volatile
        var instance: GestureTrackingService? = null
            private set

        val isRunning: Boolean
            get() = instance != null
    }
}
