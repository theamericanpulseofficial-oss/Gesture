package com.gesturecontrol.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * This is the Android equivalent of mouse_control.py's MouseController.
 * On PC, pyautogui.click() / rightClick() / scroll() drive real OS input.
 * On Android an app cannot inject input directly, so we use the
 * Accessibility API's dispatchGesture(), which is the standard, non-root
 * way to perform taps / long-presses / swipes on behalf of the user.
 */
class GestureAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "GestureAccessibilityService connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not needed for gesture dispatch, but required override.
    }

    override fun onInterrupt() {
        Log.d(TAG, "GestureAccessibilityService interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    /** Equivalent of MouseController.click() */
    fun performTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 60)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /** Equivalent of MouseController.right_click() -> long press opens Android's context menu */
    fun performLongPress(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, Config.LONG_PRESS_DURATION_MS)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /**
     * Equivalent of MouseController.scroll(steps).
     * direction > 0 -> scroll content up (finger swipes down),
     * direction < 0 -> scroll content down (finger swipes up),
     * mirroring the PC version's "hand up -> scroll up" convention.
     */
    fun performScroll(centerX: Float, centerY: Float, direction: Int) {
        val half = Config.SCROLL_SWIPE_DISTANCE_PX / 2
        val startY = if (direction > 0) centerY - half else centerY + half
        val endY = if (direction > 0) centerY + half else centerY - half

        val path = Path().apply {
            moveTo(centerX, startY.coerceIn(0f, Float.MAX_VALUE))
            lineTo(centerX, endY.coerceIn(0f, Float.MAX_VALUE))
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 200)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /** Equivalent of pressing 'Q' / the PAUSE safety state - just goes to home screen. */
    fun goHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    companion object {
        private const val TAG = "GestureAccessSvc"

        @Volatile
        var instance: GestureAccessibilityService? = null
            private set

        val isRunning: Boolean
            get() = instance != null
    }
}
