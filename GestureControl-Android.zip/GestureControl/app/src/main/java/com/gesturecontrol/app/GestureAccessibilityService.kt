package com.gesturecontrol.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.util.Log
import android.view.accessibility.AccessibilityEvent

enum class ScrollAxis { VERTICAL, HORIZONTAL }

/**
 * Android equivalent of mouse_control.py's MouseController. Android apps can't
 * inject input directly like pyautogui does on a PC, so this uses the
 * Accessibility API's dispatchGesture() - the standard, non-root way to
 * perform taps / long-presses / drags / swipes system-wide, on top of any app.
 */
class GestureAccessibilityService : AccessibilityService() {

    private var currentDragStroke: GestureDescription.StrokeDescription? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "GestureAccessibilityService connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not needed for gesture dispatch, but required override.
    }

    override fun onInterrupt() {
        Log.d(TAG, "GestureAccessibilityService interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    /** Equivalent of MouseController.click() */
    fun performTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 60)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /** Equivalent of MouseController.right_click() -> long press opens Android's context menu */
    fun performLongPress(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, Config.LONG_PRESS_DURATION_MS)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /**
     * Equivalent of MouseController.scroll(steps), extended to 4 directions.
     * direction > 0 -> hand moved up/left  -> swipe that scrolls content "forward"
     * direction < 0 -> hand moved down/right -> swipe that scrolls content "backward"
     * (mirrors the PC version's "hand up -> scroll up" convention).
     */
    fun performScroll(centerX: Float, centerY: Float, axis: ScrollAxis, direction: Int) {
        val half = Config.SCROLL_SWIPE_DISTANCE_PX / 2
        val path = Path()
        if (axis == ScrollAxis.VERTICAL) {
            val startY = if (direction > 0) centerY - half else centerY + half
            val endY = if (direction > 0) centerY + half else centerY - half
            path.moveTo(centerX, startY.coerceAtLeast(0f))
            path.lineTo(centerX, endY.coerceAtLeast(0f))
        } else {
            val startX = if (direction > 0) centerX - half else centerX + half
            val endX = if (direction > 0) centerX + half else centerX - half
            path.moveTo(startX.coerceAtLeast(0f), centerY)
            path.lineTo(endX.coerceAtLeast(0f), centerY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 200)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    // --- Drag & drop (fist + movement), using continued strokes so the OS sees
    // one uninterrupted finger-down -> move -> move -> ... -> finger-up gesture,
    // exactly like a real touch drag. Requires API 26+. ---

    /** Fist just closed: press down at this point and keep the touch "down". */
    fun startDrag(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, Config.DRAG_SEGMENT_DURATION_MS, true)
        currentDragStroke = stroke
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /** Fist still closed and hand moved: extend the same touch to the new point. */
    fun continueDrag(fromX: Float, fromY: Float, toX: Float, toY: Float) {
        val prev = currentDragStroke ?: return
        val path = Path().apply { moveTo(fromX, fromY); lineTo(toX, toY) }
        val stroke = prev.continueStroke(path, 0, Config.DRAG_SEGMENT_DURATION_MS, true)
        currentDragStroke = stroke
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /** Fist opened: lift the touch at the last known point, ending the drag. */
    fun endDrag(atX: Float, atY: Float) {
        val prev = currentDragStroke ?: return
        val path = Path().apply { moveTo(atX, atY) }
        val stroke = prev.continueStroke(path, 0, Config.DRAG_SEGMENT_DURATION_MS, false)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
        currentDragStroke = null
    }

    val isDragging: Boolean get() = currentDragStroke != null

    // --- Two-hand pinch-to-zoom, using two SIMULTANEOUS continued strokes so the
    // OS sees a real two-finger pinch/spread gesture (same GestureDescription can
    // hold multiple concurrent StrokeDescriptions for multi-touch). ---

    private var pinchStroke1: GestureDescription.StrokeDescription? = null
    private var pinchStroke2: GestureDescription.StrokeDescription? = null

    fun startPinch(x1: Float, y1: Float, x2: Float, y2: Float) {
        val path1 = Path().apply { moveTo(x1, y1) }
        val path2 = Path().apply { moveTo(x2, y2) }
        val s1 = GestureDescription.StrokeDescription(path1, 0, Config.DRAG_SEGMENT_DURATION_MS, true)
        val s2 = GestureDescription.StrokeDescription(path2, 0, Config.DRAG_SEGMENT_DURATION_MS, true)
        pinchStroke1 = s1
        pinchStroke2 = s2
        dispatchGesture(GestureDescription.Builder().addStroke(s1).addStroke(s2).build(), null, null)
    }

    fun continuePinch(
        fromX1: Float, fromY1: Float, toX1: Float, toY1: Float,
        fromX2: Float, fromY2: Float, toX2: Float, toY2: Float
    ) {
        val p1 = pinchStroke1 ?: return
        val p2 = pinchStroke2 ?: return
        val path1 = Path().apply { moveTo(fromX1, fromY1); lineTo(toX1, toY1) }
        val path2 = Path().apply { moveTo(fromX2, fromY2); lineTo(toX2, toY2) }
        val s1 = p1.continueStroke(path1, 0, Config.DRAG_SEGMENT_DURATION_MS, true)
        val s2 = p2.continueStroke(path2, 0, Config.DRAG_SEGMENT_DURATION_MS, true)
        pinchStroke1 = s1
        pinchStroke2 = s2
        dispatchGesture(GestureDescription.Builder().addStroke(s1).addStroke(s2).build(), null, null)
    }

    fun endPinch(atX1: Float, atY1: Float, atX2: Float, atY2: Float) {
        val p1 = pinchStroke1 ?: return
        val p2 = pinchStroke2 ?: return
        val path1 = Path().apply { moveTo(atX1, atY1) }
        val path2 = Path().apply { moveTo(atX2, atY2) }
        val s1 = p1.continueStroke(path1, 0, Config.DRAG_SEGMENT_DURATION_MS, false)
        val s2 = p2.continueStroke(path2, 0, Config.DRAG_SEGMENT_DURATION_MS, false)
        dispatchGesture(GestureDescription.Builder().addStroke(s1).addStroke(s2).build(), null, null)
        pinchStroke1 = null
        pinchStroke2 = null
    }

    val isZoomActive: Boolean get() = pinchStroke1 != null

    /** "Quit"/reset equivalent - goes to the home screen. */
    fun goHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    fun goBack() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun openRecents() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    companion object {
        private const val TAG = "GestureAccessSvc"

        @Volatile
        var instance: GestureAccessibilityService? = null
            private set

        val isRunning: Boolean
            get() = instance != null
    }
}
