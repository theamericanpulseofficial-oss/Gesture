package com.gesturecontrol.app

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.hypot

enum class Gesture {
    MOVE,        // index finger only -> pointer/tracking
    TAP,         // thumb+index pinch -> equivalent of PC's CLICK (left click)
    LONG_PRESS,  // thumb+middle pinch -> equivalent of PC's RIGHT_CLICK
    SCROLL,      // index+middle up (peace sign) -> equivalent of PC's SCROLL mode
    PAUSE,       // closed fist -> equivalent of PC's PAUSE
    NEUTRAL
}

data class GestureResult(val gesture: Gesture, val distance: Float = 0f)

/**
 * Direct port of gesture_recognition.py's GestureRecognizer.
 * Landmark indices are identical to the PC version (MediaPipe Hand landmark model):
 * 0=wrist, 4=thumb tip, 8=index tip, 12=middle tip, 16=ring tip, 20=pinky tip.
 */
class GestureClassifier {

    private val tipIds = intArrayOf(4, 8, 12, 16, 20) // Thumb, Index, Middle, Ring, Pinky

    fun detectGesture(landmarks: List<NormalizedLandmark>): GestureResult {
        if (landmarks.isEmpty()) return GestureResult(Gesture.NEUTRAL)

        // 1. Which of the 4 non-thumb fingers are up (tip.y < pip.y means "up", since
        //    normalized y grows downward, same convention as the PC version's pixel y).
        val fingers = IntArray(4)
        for (id in 1..4) {
            val tip = landmarks[tipIds[id]]
            val pip = landmarks[tipIds[id] - 2]
            fingers[id - 1] = if (tip.y() < pip.y()) 1 else 0
        }

        // 2. Pinch distances (normalized 0-1 space, same role as pixel distance on PC)
        val thumb = landmarks[4]
        val index = landmarks[8]
        val middle = landmarks[12]

        val distIndex = hypot((index.x() - thumb.x()).toDouble(), (index.y() - thumb.y()).toDouble()).toFloat()
        val distMiddle = hypot((middle.x() - thumb.x()).toDouble(), (middle.y() - thumb.y()).toDouble()).toFloat()

        // --- PRIORITY GESTURES (mirrors PC: clicks checked before anything else) ---
        if (distIndex < Config.PINCH_THRESHOLD) {
            return GestureResult(Gesture.TAP, distIndex)
        }
        if (distMiddle < Config.PINCH_THRESHOLD) {
            return GestureResult(Gesture.LONG_PRESS, distMiddle)
        }

        // --- STATE GESTURES ---
        // Fist = all 4 fingers down
        if (fingers.all { it == 0 }) {
            return GestureResult(Gesture.PAUSE)
        }

        // Peace sign = index + middle up, ring + pinky down
        if (fingers[0] == 1 && fingers[1] == 1 && fingers[2] == 0 && fingers[3] == 0) {
            return GestureResult(Gesture.SCROLL)
        }

        // Index only up
        if (fingers[0] == 1 && fingers[1] == 0 && fingers[2] == 0 && fingers[3] == 0) {
            return GestureResult(Gesture.MOVE)
        }

        return GestureResult(Gesture.NEUTRAL)
    }
}
