package com.gesturecontrol.app

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.hypot

enum class Gesture {
    TAP,         // thumb+index pinch -> click, at the palm-center cursor position
    LONG_PRESS,  // thumb+middle pinch -> right-click equivalent
    FIST,        // closed fist -> press+hold; combined with movement = drag & drop
    SCROLL,      // index+middle up (peace sign) -> scroll up/down/left/right
    NEUTRAL      // cursor just tracks, no action
}

data class GestureResult(val gesture: Gesture, val distance: Float = 0f)

data class PalmCenter(val x: Float, val y: Float)

/**
 * Port of gesture_recognition.py's GestureRecognizer, extended with a stable
 * palm-center point (used as the on-screen cursor position, like a real mouse,
 * instead of the PC version's fingertip-only tracking).
 */
class GestureClassifier {

    private val tipIds = intArrayOf(4, 8, 12, 16, 20) // Thumb, Index, Middle, Ring, Pinky

    fun palmCenter(landmarks: List<NormalizedLandmark>): PalmCenter? {
        if (landmarks.isEmpty()) return null
        var sx = 0f
        var sy = 0f
        for (id in Config.PALM_LANDMARK_IDS) {
            sx += landmarks[id].x()
            sy += landmarks[id].y()
        }
        val n = Config.PALM_LANDMARK_IDS.size
        return PalmCenter(sx / n, sy / n)
    }

    /** Wrist-to-middle-knuckle distance: a stable proxy for "how big the hand looks
     * right now" (varies with distance to camera), used to make the pinch threshold
     * scale-invariant instead of a fixed pixel/normalized distance. */
    private fun handScale(landmarks: List<NormalizedLandmark>): Float {
        val wrist = landmarks[0]
        val middleMcp = landmarks[9]
        return hypot((middleMcp.x() - wrist.x()).toDouble(), (middleMcp.y() - wrist.y()).toDouble()).toFloat()
            .coerceAtLeast(0.001f)
    }

    fun detectGesture(landmarks: List<NormalizedLandmark>): GestureResult {
        if (landmarks.isEmpty()) return GestureResult(Gesture.NEUTRAL)

        // 1. Which of the 4 non-thumb fingers are up (tip.y < pip.y means "up", since
        //    normalized y grows downward, same convention as the PC version's pixel y).
        val fingers = IntArray(4)
        for (id in 1..4) {
            val tip = landmarks[tipIds[id]]
            val pip = landmarks[tipIds[id] - 2]
            fingers[id - 1] = if (tip.y() < pip.y()) 1 else 0
        }

        // 2. Pinch distances, normalized by hand scale so the threshold doesn't
        //    misfire when the hand is closer to or farther from the camera.
        val scale = handScale(landmarks)
        val thumb = landmarks[4]
        val index = landmarks[8]
        val middle = landmarks[12]

        val distIndex = hypot((index.x() - thumb.x()).toDouble(), (index.y() - thumb.y()).toDouble()).toFloat() / scale
        val distMiddle = hypot((middle.x() - thumb.x()).toDouble(), (middle.y() - thumb.y()).toDouble()).toFloat() / scale

        // --- PRIORITY GESTURES (mirrors PC: clicks checked before anything else) ---
        if (distIndex < Config.PINCH_THRESHOLD_RATIO) {
            return GestureResult(Gesture.TAP, distIndex)
        }
        if (distMiddle < Config.PINCH_THRESHOLD_RATIO) {
            return GestureResult(Gesture.LONG_PRESS, distMiddle)
        }

        // --- STATE GESTURES ---
        // Fist = all 4 fingers down -> press+hold / drag trigger
        if (fingers.all { it == 0 }) {
            return GestureResult(Gesture.FIST)
        }

        // Peace sign = index + middle up, ring + pinky down -> scroll (any direction)
        if (fingers[0] == 1 && fingers[1] == 1 && fingers[2] == 0 && fingers[3] == 0) {
            return GestureResult(Gesture.SCROLL)
        }

        return GestureResult(Gesture.NEUTRAL)
    }
}
