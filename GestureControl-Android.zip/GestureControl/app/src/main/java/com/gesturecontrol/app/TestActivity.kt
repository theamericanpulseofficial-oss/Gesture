package com.gesturecontrol.app

import android.os.Bundle
import android.util.Size
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.gesturecontrol.app.databinding.ActivityTestBinding
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * In-app test mode: lets you verify the camera, hand tracking, cursor, and
 * click/drag/scroll gesture logic WITHOUT needing "Display over other apps"
 * or the Accessibility Service permission - useful when a phone's settings
 * won't let you grant those yet. Nothing here is system-wide; the cursor and
 * clicks only affect widgets inside this screen.
 */
class TestActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTestBinding
    private lateinit var cameraExecutor: ExecutorService
    private var handLandmarkerHelper: HandLandmarkerHelper? = null
    private val gestureClassifier = GestureClassifier()

    private var viewW = 0f
    private var viewH = 0f

    private var scrollTicks = 0
    private var tapCount = 0
    private var lastActionTime = 0L
    private var lastScrollX: Float? = null
    private var lastScrollY: Float? = null
    private var lastScrollTime = 0L
    private var isDragging = false

    private var sensitivity = Config.DEFAULT_SENSITIVITY
    private var cursorX = 0f
    private var cursorY = 0f
    private var hasPrevPalm = false
    private var prevPalmX = 0f
    private var prevPalmY = 0f

    private val requestCameraPermission =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else {
                binding.gestureLabel.text = "Camera permission denied"
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTestBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.btnExitTest.setOnClickListener { finish() }

        binding.testRoot.post {
            viewW = binding.testRoot.width.toFloat()
            viewH = binding.testRoot.height.toFloat()
            cursorX = viewW / 2f
            cursorY = viewH / 2f
        }

        sensitivity = getSharedPreferences(Config.PREFS_NAME, MODE_PRIVATE)
            .getFloat(Config.PREF_SENSITIVITY, Config.DEFAULT_SENSITIVITY)

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)
            == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            requestCameraPermission.launch(android.Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        handLandmarkerHelper = HandLandmarkerHelper(
            context = this,
            onResult = { result, w, h -> runOnUiThread { onHandResult(result) } },
            onError = { msg -> runOnUiThread { binding.gestureLabel.text = "Error: $msg" } }
        )

        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = androidx.camera.core.Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }

            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor) { imageProxy ->
                        handLandmarkerHelper?.detectAsync(
                            imageProxy,
                            imageProxy.imageInfo.rotationDegrees,
                            isFrontCamera = true
                        )
                    }
                }

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
            } catch (e: Exception) {
                binding.gestureLabel.text = "Camera bind failed: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onHandResult(result: HandLandmarkerResult) {
        if (viewW == 0f) {
            viewW = binding.testRoot.width.toFloat()
            viewH = binding.testRoot.height.toFloat()
            if (viewW == 0f) return
        }

        val hands = result.landmarks()
        val landmarks: List<NormalizedLandmark> = if (hands.isNotEmpty()) hands[0] else emptyList()

        if (landmarks.isEmpty()) {
            binding.overlayView.clear()
            binding.gestureLabel.text = "Gesture: - (no hand)"
            isDragging = false
            lastScrollX = null
            lastScrollY = null
            hasPrevPalm = false
            return
        }

        val palm = gestureClassifier.palmCenter(landmarks) ?: return

        if (!hasPrevPalm) {
            prevPalmX = palm.x
            prevPalmY = palm.y
            hasPrevPalm = true
        } else {
            val dx = (palm.x - prevPalmX) * sensitivity * viewW
            val dy = (palm.y - prevPalmY) * sensitivity * viewH
            cursorX = (cursorX + dx).coerceIn(0f, viewW)
            cursorY = (cursorY + dy).coerceIn(0f, viewH)
            prevPalmX = palm.x
            prevPalmY = palm.y
        }

        val gestureResult = gestureClassifier.detectGesture(landmarks)
        val now = System.currentTimeMillis()
        var color = android.graphics.Color.WHITE

        when (gestureResult.gesture) {
            Gesture.TAP -> {
                color = android.graphics.Color.parseColor("#FF9800")
                isDragging = false
                if (now - lastActionTime > Config.GESTURE_COOLDOWN_MS) {
                    lastActionTime = now
                    if (isInsideView(binding.tapTestButton, cursorX, cursorY)) {
                        tapCount++
                        binding.tapTestButton.text = "Tap test: $tapCount"
                    }
                }
                binding.gestureLabel.text = "Gesture: TAP"
            }
            Gesture.LONG_PRESS -> {
                color = android.graphics.Color.MAGENTA
                isDragging = false
                binding.gestureLabel.text = "Gesture: LONG PRESS"
            }
            Gesture.FIST -> {
                color = android.graphics.Color.RED
                isDragging = true
                moveDragBoxTo(cursorX, cursorY)
                lastScrollX = null
                lastScrollY = null
                binding.gestureLabel.text = "Gesture: FIST (dragging)"
            }
            Gesture.SCROLL -> {
                color = android.graphics.Color.CYAN
                isDragging = false
                binding.gestureLabel.text = "Gesture: SCROLL"
                val refX = lastScrollX
                val refY = lastScrollY
                if (refX == null || refY == null) {
                    lastScrollX = cursorX
                    lastScrollY = cursorY
                } else if (now - lastScrollTime > Config.SCROLL_COOLDOWN_MS) {
                    val dxNorm = palm.x - (refX / viewW)
                    val dyNorm = palm.y - (refY / viewH)
                    if (kotlin.math.abs(dxNorm) > Config.SCROLL_MOVE_THRESHOLD ||
                        kotlin.math.abs(dyNorm) > Config.SCROLL_MOVE_THRESHOLD
                    ) {
                        scrollTicks++
                        binding.scrollLabel.text = "Scroll ticks: $scrollTicks"
                        lastScrollTime = now
                        lastScrollX = cursorX
                        lastScrollY = cursorY
                    }
                }
            }
            Gesture.NEUTRAL -> {
                color = android.graphics.Color.WHITE
                isDragging = false
                lastScrollX = null
                lastScrollY = null
                binding.gestureLabel.text = "Gesture: -"
            }
        }

        binding.overlayView.update(landmarks, cursorX, cursorY, color)
    }

    private fun moveDragBoxTo(x: Float, y: Float) {
        val box = binding.dragBox
        box.x = x - box.width / 2f
        box.y = y - box.height / 2f
    }

    private fun isInsideView(view: android.view.View, x: Float, y: Float): Boolean {
        val loc = IntArray(2)
        view.getLocationInWindow(loc)
        return x >= loc[0] && x <= loc[0] + view.width && y >= loc[1] && y <= loc[1] + view.height
    }

    override fun onDestroy() {
        super.onDestroy()
        handLandmarkerHelper?.close()
        cameraExecutor.shutdown()
    }
}
